#!/usr/bin/env python3
from ncclient import manager
import time
from datetime import datetime
import subprocess
import xml.dom.minidom
from scapy.all import send,IP,UDP,Raw,AsyncSniffer
from pprint import pprint
import json
import yaml
from yaml.loader import SafeLoader
import logging
import sys
import argparse
import threading
import socket
from multiprocessing import Process
import xml.etree.ElementTree as ET
from ncclient.xml_ import to_ele

UDP_NOTIF_PORT = '10003'
TEST_HOST_IP = '127.0.0.1'
LOGFILE = 'not_set'
PCAP_PATH = './'
LOGFILE_PATH = './'
XML_PATH = './'

class MyUdpListener(Process):
    import socket
    import json
    import sys
    def __init__(self, ip, port):
        Process.__init__(self) 
        self.localIP     = str(ip)
        self.localPort   = int(port)
        self.bufferSize  = 2048 #Default: 1024, needed to be adjusted to support one full interface dump

    def run(self):
        self.UDPServerSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
        self.UDPServerSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.UDPServerSocket.bind((self.localIP, self.localPort))
        logging.warning("UDP server up and listening on port: "+str(self.localPort))
        while True:
            self.bytesAddressPair = self.UDPServerSocket.recvfrom(self.bufferSize)
            self.message = self.bytesAddressPair[0]
            try:
                self.j = json.loads(self.bytesAddressPair[0][12:].decode('utf-8'))
            except:
                self.j = {"error":"was not json parsable", "raw": str(self.bytesAddressPair[0])}
            self.address = self.bytesAddressPair[1]
            self.clientIP  = "Client IP Address:{}".format(self.address)
            print("\n")
            print(self.clientIP)
            print(json.dumps(self.j, indent=1))


def nc_config(conn, infile):
    with open(infile, "r") as f:
        conf_sub = '<config xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">'+f.read()+'</config>'   
    logging.warning("===> Sending NC config:\n"+str(conf_sub)+"<===\n")
    send_config = conn.edit_config(target='candidate', config=conf_sub, default_operation='merge')
    conn.commit()

def nc_rpc(conn, infile):
    with open(infile, "r") as f:
        rpc_sub = f.read()
    rpc_payload_xml = to_ele(rpc_sub)
    result = conn.dispatch(rpc_payload_xml)
    dom = xml.dom.minidom.parseString(result.xml)
    pretty_xml_as_string = dom.toprettyxml()
    logging.warning("===> Get YP subscriptions:\n"+str(pretty_xml_as_string)+"<===\n")


def nc_get_subscriptions(conn):
    result = conn.get(filter=("subtree", "<subscriptions/>"))
    dom = xml.dom.minidom.parseString(result.xml)
    pretty_xml_as_string = dom.toprettyxml()
    logging.warning("===> Get YP subscriptions:\n"+str(pretty_xml_as_string)+"<===\n")

def nc_delete_subsciption_and_receivers(conn):
    infile = XML_PATH + "yp-cisco-delete-yp.xml"
    with open(infile, "r") as f:
        conf_sub = '<config xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">'+f.read()+'</config>'   
    logging.warning("===> Sending NC config:\n"+str(conf_sub)+"<===\n")
    send_config = conn.edit_config(target='candidate', config=conf_sub, default_operation='merge')
    conn.commit()

def info_packet(text="No text set"):
    logging.warning("sending info packet with SYSLOG: "+str(text))
    a = IP(dst=TEST_HOST_IP, src=TEST_HOST_IP)/UDP(sport=514, dport=514)/Raw(load="<181>"+text) #str(bytearray("0"*35, 'utf-8'))+text) #35 Bytes is  YP header 
    send(a, verbose=False)

def set_wait_interval(seconds, args):
    if args.override_timer: return int(args.override_timer)
    else: return seconds

def launch_test(host, user, password, args):

    pcap_name = PCAP_PATH +'yp-test-'+time.strftime("%Y%m%d-%H%M%S")+'.pcap'
    logging.warning("starting tcpdump:"+str(pcap_name))
    pid_tcpdump = subprocess.Popen(['tcpdump', '-i', 'any', 'udp','port','10003','or','udp','port','514','-w', pcap_name], stdout=subprocess.PIPE)

    print("starting udp-listener:", TEST_HOST_IP,"on port:", UDP_NOTIF_PORT)
    t_udplistener = MyUdpListener(TEST_HOST_IP, UDP_NOTIF_PORT)
    t_udplistener.start()

    t = AsyncSniffer(iface="ietf", filter="udp port 10003")
    t.start()

    logging.warning("Since logging.warning is enabled you will see all actions and packets received inline\nA summary is given at the end.")

    conn = manager.connect(host=host, username=user, password=password, timeout=10, hostkey_verify=False)

    nc_get_subscriptions(conn)  

    if args.test0 or args.all:
        info_packet("--- TEST 0 - Capabilities ---")
        xml_file = XML_PATH + "discover-yang.xml" # Schemas
        info_packet("--- Step 0.0: get "+xml_file)
        nc_rpc(conn, xml_file)
        xml_file = XML_PATH + "get-yang-library.xml" # RFC 8525
        info_packet("--- Step 0.1: RFC 8525 -  get "+xml_file)
        nc_rpc(conn, xml_file)


    if args.test1 or args.all:
        info_packet("--- Step 0.2: remove YP config on router (if leftover from last test)")    
        nc_delete_subsciption_and_receivers(conn)

        info_packet("--- TEST 1 - YANG Push periodical subscription ---")
        xml_file = XML_PATH + "yp-cisco-test-yp-periodic-3000cs.xml" # 6000cs
        info_packet("--- Step 1.0: config subscription"+xml_file)
        nc_config(conn, xml_file)
        nc_get_subscriptions(conn)

        wait_interval = set_wait_interval(300, args=args)
        info_packet("--- Step 1.1: start of wait "+str(wait_interval)+"s")
        time.sleep(wait_interval)
        info_packet("--- Step 1.2: end of wait "+str(wait_interval)+"s")

        info_packet("--- TEST 1b - YANG Push periodical change interval subscription ---")
        xml_file = XML_PATH + "yp-cisco-test-yp-periodic-4500cs.xml" # 6000cs
        info_packet("--- Step 1b.0: config subscription"+xml_file)
        nc_config(conn, xml_file)
        nc_get_subscriptions(conn)

        wait_interval = set_wait_interval(300, args=args)
        info_packet("--- Step 1b.1: start of wait "+str(wait_interval)+"s")
        time.sleep(wait_interval)
        info_packet("--- Step 1b.2: end of wait "+str(wait_interval)+"s")

    if args.test2 or args.all:
        info_packet("--- TEST 2 - change yp periodic interval time and xpath with same subscription ID---")
        '''
        RFC 8641: YANG-Push    
          A configured subscription cannot be modified using a "modify-subscription" RPC.  
          Instead, the configuration needs to be edited as needed.
        '''
        xml_file = XML_PATH + "yp-cisco-test-yp-periodic-12000cs-anchored.xml"
        info_packet("--- Step 2.0: config subscription"+xml_file)
        nc_config(conn, xml_file)
        nc_get_subscriptions(conn)

        wait_interval = set_wait_interval(600, args=args)
        info_packet("--- Step 2.1: start of wait "+str(wait_interval)+"s")
        time.sleep(wait_interval)
        info_packet("--- Step 2.2: end of wait "+str(wait_interval)+"s")


    info_packet("--- Step 2.3: remove subscription")
    nc_delete_subsciption_and_receivers(conn)
    nc_get_subscriptions(conn)  

    if args.test3 or args.all: 
        info_packet("--- TEST 3 - YANG Push on-change sync-on-start ---")
        xml_file = XML_PATH + "yp-cisco-test-yp-on-change.xml"
        info_packet("--- Step 3.0: config subscription"+xml_file)
        nc_config(conn, xml_file)
        nc_get_subscriptions(conn)

        wait_interval = set_wait_interval(60, args=args)
        info_packet("--- Step 3.1: start of wait "+str(wait_interval)+"s")
        time.sleep(wait_interval)
        info_packet("--- Step 3.2: end of wait "+str(wait_interval)+"s")

        info_packet("--- Step 3.3: Set Loopback down")
        xml_file = XML_PATH + "yp-cisco-test-set-loopbackA3-down.xml"
        nc_config(conn, xml_file)

        info_packet("--- Step 3.4: start of wait "+str(wait_interval)+"s")
        time.sleep(wait_interval)
        info_packet("--- Step 3.5: end of wait "+str(wait_interval)+"s")

        info_packet("--- Step 3.6: Set Loopback up")
        xml_file = XML_PATH + "yp-cisco-test-set-loopbackA3-up.xml"
        nc_config(conn, xml_file)

        info_packet("--- Step 3.7: start of wait "+str(wait_interval)+"s")
        time.sleep(wait_interval)
        info_packet("--- Step 3.8: end of wait "+str(wait_interval)+"s")

        info_packet("--- Step 3.9: Set Loopback down")
        xml_file = XML_PATH + "yp-cisco-test-set-loopbackA3-down.xml"
        nc_config(conn, xml_file)

        info_packet("--- Step 3.10: start of wait "+str(wait_interval)+"s")
        time.sleep(wait_interval)
        info_packet("--- Step 3.11: end of wait "+str(wait_interval)+"s")

        info_packet("--- Step 3.12: Set Loopback up")
        xml_file = XML_PATH + "yp-cisco-test-set-loopbackA3-up.xml"
        nc_config(conn, xml_file)

        info_packet("--- Step 3.13: start of wait "+str(wait_interval)+"s")    
        time.sleep(wait_interval)
        info_packet("--- Step 3.14: end of wait "+str(wait_interval)+"s")

        info_packet("--- Step 3.15: remove subscription")    

        nc_delete_subsciption_and_receivers(conn)
        nc_get_subscriptions(conn)  


    if args.test4 or args.all: 
        info_packet("--- TEST4 - UDP Notif Segmentation ---")
        xml_file = XML_PATH + "yp-cisco-test-yp-periodic-3000cs-segmented.xml"
        info_packet("--- Step 4.0: config subscription"+xml_file)
        nc_config(conn, xml_file)
        nc_get_subscriptions(conn)

        wait_interval = set_wait_interval(300, args=args)
        info_packet("--- Step 4.1: start of wait "+str(wait_interval)+"s")
        time.sleep(wait_interval)
        info_packet("--- Step 4.2: end of wait "+str(wait_interval)+"s")

        info_packet("--- Step: remove subscription")    

        nc_delete_subsciption_and_receivers(conn)
        nc_get_subscriptions(conn)  



    conn.close_session()

    wait_interval = set_wait_interval(60, args=args)
    info_packet("--- Step 5: wait "+str(wait_interval)+"s for last msgs")
    time.sleep(wait_interval)
    info_packet("--- END OF TESTS \---")      
    
    t.stop()

    logging.warning("\n\n"+"="*30+"TEST SUMMARY"+"="*30)
    logging.warning("\nPackets received: \n"+"-"*30+"\n")
    #t.results.show()
    logging.warning("\n".join([str(i) for i in t.results]))
    logging.warning("-"*30)
    logging.warning("length of capture:"+str(len(t.results)))
    logging.warning("\n"+"="*20+" DETAILS "+"="*20+"\n")
    msgs = list()
    for pkt in t.results:
        try:
            j = json.loads((pkt.getlayer(Raw).getfieldval("load"))[12:].decode('utf-8'))
        except:
            j = json.loads('{"msg":"error"}')
        msgs.append(j)
        try:
            yp = j.get("ietf-notifications:notification")
            for k,v in yp.items():
                if k in ['eventTime', 'sysName', 'publisherId', 'sequenceNumber']:
                    logging.warning(str(k)+": "+str(v))
                else:
                    logging.warning(str(k)+" length("+str(len(v))+")")
            logging.warning("\n"+"-"*50+"\n")
        except:
            logging.error("ERROR WITH j.get(\"ietf-notifications:notification\")\n"+str(j))

    if args.verbose or args.very_verbose: logging.warning("="*20+"ALL PACKETS RECEIVED"+"="*20+"\n"+json.dumps(msgs, indent=1))
   
    pid_tcpdump.send_signal(subprocess.signal.SIGTERM)
    logging.warning("\nstopped tcpdump: "+pcap_name+"\n")
    t_udplistener.terminate()
    logging.warning("terminating udp-listener on port: "+str(UDP_NOTIF_PORT)+"\nBYE\n")
    if LOGFILE != 'not_set': logging.warning("Logfile: "+str(LOGFILE)+"\n")


if __name__ == '__main__':
    
    parser = argparse.ArgumentParser(
                    prog='yp-test-suite.py',
                    description='YANG Push Test Suite - simple automation (taabuya2, 2024)',
                    epilog='enjoy')

    parser.add_argument('-vv', '--very_verbose', action='store_true')  
    parser.add_argument('-v', '--verbose', action='store_true') 
    parser.add_argument('-a', '--all', action='store_true')
    parser.add_argument('-t0', '--test0', action='store_true')
    parser.add_argument('-t1', '--test1', action='store_true')
    parser.add_argument('-t2', '--test2', action='store_true')
    parser.add_argument('-t3', '--test3', action='store_true')
    parser.add_argument('-t4', '--test4', action='store_true')
    parser.add_argument('-o', '--override_timer')
    parser.add_argument('-c', '--config', type=str, required=True, help="Config file",) 
    args = parser.parse_args()

    with open(args.config) as f:
        config = yaml.load(f, Loader=SafeLoader)

    UDP_NOTIF_PORT = config['RECEIVER'].get("udp_notif_port", UDP_NOTIF_PORT)
    TEST_HOST_IP = config['RECEIVER'].get("ip", TEST_HOST_IP)
    PCAP_PATH = config['OUTPUT'].get("pcap", PCAP_PATH)
    LOGFILE_PATH = config['OUTPUT'].get("log", LOGFILE_PATH)
    XML_PATH = config['INPUT'].get("xmls", XML_PATH)

    LOGFILE = LOGFILE_PATH + "yp_test_suite_report_"+str(datetime.now().strftime("%Y%m%d_%H%M%S"))+".log"
    if args.very_verbose: logging.basicConfig(level=logging.DEBUG)
    elif args.verbose: logging.basicConfig(level=logging.WARNING,
        format='%(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),  # Print to console
            logging.FileHandler(LOGFILE, delay=True)  # Log to file
        ]
    )
    else: logging.basicConfig(level=logging.ERROR)

    launch_test(config['DUT'].get("ip"), config['DUT'].get("username"), config['DUT'].get("password"), args)
